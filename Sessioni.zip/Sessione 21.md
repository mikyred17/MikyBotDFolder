
## Eventi

### Dopo battaglia

Dopo la battaglia Thalrik cerca di convincere a prendere il pene del gigante dopo un po di via vai riesce a convincerlo, puzza da morire e lo mettiamo nella netherbags.

### Viaggio

Appena ripartiamo mando un messaggio a Roland per sapere se e passato dal confine.
Io
> Dove sei arrivato con il carico?

Roland
> Sono arrivato ad Hargast il carico e tutto pronto, in piu ho novita

Ripartiamo il viaggio dura una giornata avendo fatto marcia forzata, durante esso non ci sono grandi eventi se non che Thalrik da al mimic il miele che lo apprezza molto.

### Cancelli di Hargast

Arrivati ad hargast le guardie (fanno parte della guarnigione di Aresil per i colori delle loro armature) ci fermano poi notanto un Duergar iniziano a fare domande trovandolo sospetto ma grazie a jin e la sfacciatagine di Thalrik fingendo di conoscere il capitano [[Philomena]] ci lasciano passare senza problemi.

### Addio Roland

Ci ritroviamo con roland nelle stalle che si prepara ad andarsene, il suo compagno la seppelito qui ad Hargast un citta tranquilla.

Prima di dirci addio ci avvisa che a Ravenholm ce in corso una pandemia, "probabilmente si tratta di quella strana febbre", poi gli chiediamo alcune informazioni sulle [[Mani d'Ombra]], ci racconta un paio di cose poi andiamo in taverna.


### Taverna

Poco prima di entrare sento in nanino *"Dove si trova la vena piu pura"* questa e una frase in codice per farsi riconoscere tra membri della [[Legione di Karak-Dûm|Legione]].

Mi giro e riconosco [[Kragvar]] un tirapiedi di mio [[Bhardus|"Padre"]], io rispondo *"Nella roccia più oscura"* continuando in nanico e lui inizia a chiedere novita sulla missione, io gli dico che mi sto ancora occupando della missione ma non ho ancora avuto risultati, lui ribadisce che forse sono stato occupato a farmi degli amici invece che completare la missione.

Poi mi chiede di andare a parlare con lui da solo si gira e si sieda ad un tavolo, io rimango un attimo con gli altri ed esitando mi giro per chiedergli aiuto (in questo momento sono spaventato), inspazientito si alza e mi richiama questa volta anche gli altri si siedono.

A tavola continua con il suo discorso e dice:
> Sapevo che non ci si doveva fidare di uno sporco elfo come strumento.

Continua dicendo:
> [[Bhardus]] con questa missione ha la possibilita di prendere il posto di [[Morgrin]] nella tavola di granito e tu non hai niente tra le mani, hai idea delle conseguenze.
> [[Bhardus]] ha fatto bene a sgozzare i tuoi genitori e che dovevo fare la loro stessa fine.

Questa frase non fa che infuocare i miei dubbi, e quella che prima era paura diventa rabbia, inizia ad allontanarsi quando io creo un collegamento telepatico con gli altri annuncio che il nano deve morire.

### Il Piano

[[Jin]] controvoglia non prova a convincermi ma grazie all'intelligenza di [[Thalrik]] elabora un piano per non ucciderlo dato che aveva fatto una promessa a [[Jin]], quindi mi fa diventare invisibile e gli prendo un sacchetto di droga, e poco prima che se ne va gliela infilo nello zaino.

Poi lascio il compito a [[Jin]] di chiamare delle guardie per incolpare [[Kragvar]] una guardia lo perquisisce e cosi lo porta dalla piccola guarnigione, io li continuo a seguire invisibile, poi mi fermo fuori da essa quando loro 2 entrano.

## Fine Sessione

Ci fermiamo quando loro 2 entrano nella guarnigione di [[Hargast]].

## Elenco

#### Personaggi
- [[Kragvar]] - Tirapiedi di mio padre.

#### Luoghi
- .

#### Oggetti
- .
