
## Eventi

### La Guarnigione

Dopo che [[Jin]] finisce di parlare con il comandante di [[Hargast]] ([[Tavros]]) esce e ci racconta cosa era quella [[La Nebbia|Droga]] e che il nano restera in prigione per un ciclo lunare (un mese circa, da 18/06/1780).

Mentre gli altri dicono a [[Deymar]] di prendere il carro e partire per [[Ravenholm]] dandogli anche la pietra comunicante che avevamo dato a [[Roland]] poi va a prendere il carro con le spezie per [[Kirmit|Kirmit]] e parte.

### In gruppo

Ci riuniamo con gli altri e parliamo:
- Di [[Korvian]]:
	Che si e incontrato con [[Zubel]] raccontando dell'accaduto ad [[Arenthia]] con il gruppo formato dai 4 individui che hanno attacato il villaggio, si sono diretti dal gruppo di Tiefling cercando il corpo di [[Vanda]] (Probabile avevano qualche magia per individuarne il corpo), loro sono stati tutti massacrati e [[Korvian|lui]] è l'unico sopravvisuto, chiede aiuto a [[Zubel]] chiedendo le informazioni ottenute [[Zubel]] rifiuta.

- Delle 4 Figure ad [[Arenthia]]:
	Intuiamo che se stavano cercando il corpo con qualche magia conoscono magie per far parlare il cadavere, insinuando che se possono probabilmente sono sulle nostre tracce.

- Di [[Kragvar]] il tirapiedi di mio padre:
	Gli racconto tutta la storia raccontandogli della [[Legione di Karak-Dûm]], mi sento quasi al sicuro con loro e infine ringrazio [[Jin]] per l'aiuto che mi ha dato.

### Vendite in citta

Decidiamo di dividerci per vendere le armi e controllare la pozione viola per poi partire.

Io e [[Thalrik]] vendiamo le armi e lui compra del miele per il mimic, mentre [[Jin]] e [[Zubel]],
una volta finito ci raccontano che la pozione e una pozione di cura.



## Fine Sessione
Finiamo a poco da [[Aresil]] mentre decidiamo cosa fare con il sacchetto.

## Elenco

#### Personaggi
- .

#### Luoghi
- .

#### Oggetti
- .
