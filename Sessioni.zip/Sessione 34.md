
## Eventi

### 1° Giorno di Viaggio

#### Chiacchere
Partiamo e si inizia a chiaccherare di cio che verra e cio che e stato, thalrik e silenzioso e keal iniza a parlargli.

parliamo:
- Come mai conosceva gia Tarabas: thalrik risponde che e un mago affermato nella legione e che parlavano dei suoi oggetti magici molto potenti.
- Poi chiedo se centrava con l'anomalia del suo regno: Lui dice che non centra poi gli altri chiedono cosa sia, lui racconta che non e nato nell'Underdark e che l'anomalia ha fatto fuggire tutti.
- Poi chiede a Jin come mai e rimasto fuori: lui risponde che non voleva lasciare gli oggetti sacri.
- Continua chiedendo come mai non si fida; jin risponde che la sua fama di non farsi scrupoli lo spaventa e quindi non si fida.
- Poi Thalrik vuole indagare sulla [[- Indovina]] visto che stiamo andando a nord, e raccontiamo a Kael cio che e successo (raccontiamo delle nostre profezie).
- Jin chiede come mai nel documento dell'elydrasse si e firmato Raggiato: Thalrik risponde che lo condivide con sua sorella, sono i primi duergar che sono nati sotto la luce del sole.
- Chiedo se l'anomalia era di divinazione: Thalrik dice di si.
- Poi Kael chiede se studia divinazione per quello: Thalrik dice di no.
- Poi si discute sulla Divinazione:
	- Jin: Pensa che il futuro sia gia scritto.
	- Thalrik Pensa che non ci sia una strada e non si spiega perche dovrebbe essere cosi.
	- Kael: Pensa che sia scritto ma che ne si possa modificarne il cammino con sprezzi del futuro.
	- Io: Ognuno fa le proprie scelte e non ce nulla di scritto il futuro e vago e facilmente manipolabile.

#### Viaggio

- Io: Vado a caccia.
- Thalrik: Addestra il mimic ( Kael chiede spiegazioni ).
- Kael: Va a raccogliere.
- Jin: Pensa.

#### La Sera

La sera parliamo della lampada ma jin e ancora insicura se usarla e dice di tenere il desiderio per il momento opportunuo.
Poi chiedo se l'ha mai identificata, e thalrik dice di no, cosi lo fa, decidiamo di usarla la mattina dopo per permettere a jin di prepararsi bene.

##### I geni

Genio dell’Aria = Djinni  
Genio dell’Acqua = Marid  
Genio del Fuoco = Efreeti  
Genio della Terra = Dao

### 2o Giorno

#### Mattina
La mattina jin si prepara a pregare, mentre si prepara kael dice che cerano 4 corvi la notte scorsa e thalrik dice che di solito i corvi non sono animali notturni.
Poi Jin vuole fare il rituale e mette la mano poi fa un giuramento a turno lo facciamo tutti e sta volta funziona.
###### I Giuramenti
- Jin: Se parla non puo mentire o deviare dalla verita.
- Kael: Prometto di attaccare per primo e di farlo solo per autodifesa.
- Thal: Promette di raccontare tutto cio che intuisce a noi per oggi.
- Io: Prometto di non derubare, solo per un guadagno personale.

#### Il Genio
Thalrik inizia a strofinare la lampada, e diventa illuminato, poi lo fa jin e diventa illuminato, lo fa kael e diventa illuminato.

#### Sera
- Io: Vado a caccia.
- Kael: cerca pozioni.
- Thalrik: addestra il mimic.
- Jin: nulla.

Poi ci accampiamo e thalrik si avvicina a jin e gli dice che non e a favore di rodhrass e che il capo del porto e colluso con rodhrass per nasconderle e chiaccherano di rodhrass.

#### Messaggio di Deymar

Dalla pietra arriva un messaggio.
> Qui Deymar. Il carro è all’ovile, pure il cavallo. La paga vi aspetta, pure il mezz’orco. Se respirate ancora… complimenti sinceri. Passo e chiudo.

Poi rispondo:
> Siamo ancora tutti interi, Li ancora ce l'epidemia?, Ti troveremo o partirai? Se parti facci sapere dove che se scopriamo qualcosa nelle vicinanze ti avvertiamo.

#### Notte 
Prima di andare a dormire dalla foresta sentiamo uno starnuto nella foresta...

## Fine Sessione
Nella notte della foresta...

## Elenco

#### Personaggi
- .

#### Luoghi
- .

#### Oggetti
- .
