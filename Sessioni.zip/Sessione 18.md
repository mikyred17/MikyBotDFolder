## Eventi

### Tempio dei giganti

Dopo lo scontro riprendiamo il cammino ma dopo un paio di ore [[Jin]] sente una presenza divina che proviene da una collinetta, ci fermiamo per capire meglio consci del rischio di giganti, [[thalrik]] manda avanti il suo famiglio e ci dice che ha visto una faccia gigante scolpita nella roccia e poi tutto pieno di sangue decidiamo quindi di non correre il rischio.

### Druidico

Mentre ci allontianiamo [[Zubel]] scorge una pietra con qualche incisione in druidico, indica un percorso per un rifugio sicuro, decidiamo quindi di seguirlo e arriviamo ad un'entrata di una grotta abbastanza grande ma non troppo profonda, [[thalrik]] diventa invisibile e una volta dentro troviamo una zona allestita con arredi di proporzione piu piccoli del normale, dopo un po di ricerca notiamo muoversi qualcosa tra le strane piume ammassate in un angolo, dopo poco si alza un halfling e per un attimo e sbalordito da noi poi si avvicina per prendere da bere qualcosa e poi si ristupisce dopo aver capito che siamo reali, lui dice che sente le voci dopo un po di discorsi facciamo entrare gli altri e [[thalrik]] si toglie l'invisibilita.

si presenta come [[Brillo]] e dopo aver chiaccherato un po, ci indica una strada per evitare i giganti e ci da delle informazinoi anche sul roc, sembra serbare qualcosa visto che non ci voleva lasciare andare e la sera dopo cena mette qualche erba particolare e genera un fumo profumato io e [[thalrik]] ce ne andiamo fuori mentre [[zubel]] resta dentro. 

poi [[thalrik]] ne approffitta per dar da mangiare al mimic che rifiuta si incazza sputa fuori l'obolo oscuro e tenta di scappare lo fermiamo ma gli altri fanno domanda su questo oggetto gli spieghiamo che e di molto valore e serve per chiedere favori facilmente.

### Notte

La notte facciamo i turni verso la mattina sentiamo il gufo di [[thalrik]] svolazzare e segnalare qualcosa notiamo un piccolo ragnetto che sta andando via dalla tana, capiamo che si tratta di Brillo che tenta di scappare lo obblighiamo a rimanere in casa e la mattina successiva di capire che intenzioni aveva con l'aiuto di [[Jin]] e la sua magia.

---

### Mattina e interrogatorio

una volta svegli [[Jin]] si prepare e con la magia usa "Zona di verita" io e deymar ci siamo allontanati per non essere in mezzo mentre gli altri restano dentro, dopo un breve discussione capiamo che brillo ci voleva tendere un'inboscata con i giganti per causa di [[thalrik]], brillo ha un trauma, era stato preso in schiavo da piccolo con i suoi genitori da un clan di Duergar.
Fortunatamente con "Zona di verita" riusciamo ad ottenere un percorso sicuro, subito dopo partiamo.

### Missiva di Vanda

Durante il viaggio ne approfitiamo per leggere la missiva, in essa c'e scritto ... DS

## Fine Sessione
Appena dopo aver letto la missiva di [[Vanda]].

## Elenco

#### Personaggi
- [[Brillo]]: Halfling che abita nelle colline dei Giganti.

#### Luoghi
- Villaggio dei Giganti: Gruppo di Giganti sono "Amici" di Brillo.
- Altare dei Giganti: Altare dove ci fanno riti.
- Caverna di Brillo: Dove abita.

#### Oggetti
- 
