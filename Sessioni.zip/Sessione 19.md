
## Eventi

### Erbe Bruciate

La notte prima di andare a dormire Brillo prende qualche erba e le butta sul fuoco, si sprigiona un fumo bianco e profumato, noto che [[Thalrik]] si alza ed esce fuori io lo segue pensado che avesse riconosciuto qualcosa e andiamo fuori dalla grotta, restiamo fuori fino a che il fumo non smetta, poi rientriamo e andiamo a letto.

### Attivita leggera

Prima che la sera finisca [[Thalrik]] ne approffitta per dar da mangiare al mimic che rifiuta e tenta di scappare lo fermiamo ma quando e calmato il mimic risputa l'Obolo oscuro e gli altri iniziano a fare domande su questo oggetto gli spieghiamo che e di molto valore e serve per chiedere favori facilmente.

### La Notte

La notte facciamo i turni verso la mattina sentiamo il gufo di [[thalrik]] svolazzare e segnalare qualcosa notiamo un piccolo ragnetto che sta andando via dalla tana, capiamo che si tratta di Brillo che tenta di scappare lo obblighiamo a rimanere in casa e la mattina successiva di capire che intenzioni aveva con l'aiuto di [[Jin]] e la sua magia.

---

### Mattina e interrogatorio

una volta svegli [[Jin]] si prepare e con la magia usa "Zona di verita" io e deymar ci siamo allontanati per non essere in mezzo mentre gli altri restano dentro, dopo un confronto capiamo che brillo ci voleva tendere un'inboscata con i giganti per causa di [[thalrik]], brillo ha un trauma, era stato preso in schiavo da piccolo con i suoi genitori da un clan di Duergar.
Fortunatamente con "Zona di verita" riusciamo ad ottenere un percorso sicuro, subito dopo partiamo.

### Missiva di Vanda

Durante il viaggio ne approfitiamo per leggere la missiva, in essa c'e scritto ... DS

## Fine Sessione

In viaggio per [[Eldoria]] subito dopo aver letto la missiva di [[Vanda]].

## Elenco

#### Personaggi
- .

#### Luoghi
- .

#### Oggetti
- Missiva di [[Vanda]]: Contiene informazioni utili.
