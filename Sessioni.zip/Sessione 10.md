## Eventi

#### Partenza e incontro con le guardie di Eldoria
La mattina ci svegliamo e ripartiamo. Dopo poco, raggiungiamo il confine dove è stato eretto un blocco dalle guardie di Eldoria. Dalle armature, io e Thalrik riconosciamo che sono la guarnigione di Aresil. Decidiamo di avanzare senza Roland, dato che è ricercato, quindi Thalrik lo fa diventare invisibile. Poi lui scende e aggira il blocco, mentre noi proseguiamo verso di esso.  
Arrivati al blocco, una guardia si avvicina e inizia a ispezionare, facendo domande. Ci dice che a breve verrà bloccato il confine. Quando chiede perché stavamo andando oltre, Jin risponde che eravamo in cerca dell'artefatto per curiosità. Io rimango stupito, poiché volevamo tenere un basso profilo, ma per convincere meglio la guardia, dico che la missione ci è stata affidata dal Sancta Fides.  
La guardia chiama un ufficiale che ci chiede un paio di cose, e poi chiediamo un lasciapassare che lui ci darà, ma varrà solo se la nostra storia è veritiera.

#### Ricongiungimento e cambiamenti di percorso
Ci ricongiungiamo con Roland e ripartiamo. Decidiamo di non passare da Arenthia, ma a poche ore da essa, Roland indica un'altra strada e noi la seguiamo. Dopo un'oretta, raggiungiamo una steppa che segna l'ingresso di un labirinto di canyon. La strada è stretta e molto irregolare.  
Sbattiamo un po' il carro, dato che è difficile passare, ma alla fine arriviamo in una zona più aperta, dove troviamo un carro malmesso e noto dell'oro al suo interno. 

#### L'attacco delle formiche
Ci fermiamo, ma non facciamo in tempo a esplorare che veniamo attaccati da delle formiche, i Three-Kri. Dopo un breve scontro jin fa un tentativo di comunicare fallendo, cosi decidiamo di scappare.

#### Fiore misterioso e tentativo di raccolta
Mentre scappiamo, notiamo un grande fiore. Usciamo dal canyon e ci fermiamo un attimo per riprenderci. Thalrik decide di andare a prendere il fiore. Si rende invisibile e avanza, ma attira un po' l'attenzione. Tuttavia, riesce a scappare senza conseguenze.

### Fine Sessione
Io e thalrik siamo a poco dal carro che torniamo con il fiore.

## Elenco

#### Personaggi
- .

#### Luoghi
- .

#### Oggetti
- .


