
## Eventi

### La Droga

Sistemiamo la questione del sacchetto caduto nel camino, [[Thalrik]] mi fa diventare invisibile e io mi introduco nella casa da una finestra che danneggio, dentro una bambina aveva raccolto il sacchetto e consegnato ai genitori, che poi hanno riposto su uno scaffale, lo prendo senza problemi e poi torno dagli altri, e ci sbarazziamo dei sacchetti mentre ero ancora invisibile.

### Cancelli di Aresil

Arrivati davanti all'entrata veniamo fermati da delle guardie che stanno ispezionando tutti quelli che entrano molto piu accuratamente di quando siamo stati li la prima volta.

Durante i controlli ci viene chiesto di svuotare gli zaini poi chiede spiegazioni sullo zaino magico insospettito, alla fine consegniamo il permesso del confine e riusciamo ad entrare, ma prima ci avverte di stare lontani dal porto e di non creare problemi.

### In Citta

Dentro la zona e come l'ultima volta piena di fumi e polveri, ci avviamo per la bottega di [[Thorian]] e mentre passiamo dalla piazza dove si intravede il porto, la piazza e affollata e dal carro notiamo una grossa nave draconica con quelle che sembrano scaglie argentate sui fianchi, poi 3 figure si avviano alla nave ne riconosco una [[Philomena]], in lontananza vedo le navi salpate per pescare e dietro alla nave dei dragonidi noto una zona che le barche evitano.
Poi essendoci troppa gente per proseguire con il carro e i resti del Roc decidiamo di avviarci alla bottega di Thorian.

Prima di arrivare [[Thalrik]] chiede se vogliamo mostrare il [[Grimvox]] a sua sorella che forse ci può aiutare noi accettiamo ma solo se ne era sicuro lui stesso.

### Alla Bottega

Bussiamo e ci apre [[Reikala|Reikala]] che esce e chiude la porta poi [[Thalrik]] la presenta agli altri, gli mostriamo i resti del Roc e il cazzo di gigante, poi la porta si apre e [[Thorian]] esce, [[Reikala]] lo avvisa subito che non siamo piu "ricercati", cosi si tranquillizza un minimo e dopo rientra.

- Con [[Reikala]] andiamo a vendere i pezzi:
	- **8 Piume** ( *20mo*, 5m, 40Kg )
	- **6 Artigli** ( *100mo*, 1.2m, 40Kg ) "1 rovinato"
	- **1 Becco** ( *300mo*, 2.5m, 120Kg )
- **TOT**: 1060 / 4 = *265mo*

##### Pozione del Gigante
Torniamo alla bottega e andiamo nel laboratorio di [[Reikala]] una piccola disordinata e caotica. [[Reikala]] e [[Thalrik]] iniziano a lavora il pene del gigante per crearne una specie di pozione, sale una puzza vomitevole.

##### Mimic e Varnhald
Poi [[Thalrik]] le mostra il mimic e lei gli racconta la storia di [[Varnhald Trasmir]], un mago che voleva che gli oggetti magici avessero una coscienza e un pensiero proprio, lui vendeva oggetti magici dall'aspetto normale ma che nascondevano un mimic, il quale sbranava il cliente e infine il mago riprendeva l'oggetto e cosi riusciva a sfamarli. Viveva tra il 700 - 800 e le sue ultime traccie sono  a [[Belaver]] e la sua creazione piu grande fu un mimic di nome **Agloss**.

##### Accademia
Poi [[Zubel]] accenna di volere visitare l'accademia e [[Reikala]] dice di andare a parlare con [[Borin]] il preside dell'accademia.

##### Grimvox
Poi [[Thalrik]] in cerca di una conferma nei nostri sguardi e inizia a parlare del [[Grimvox]] a [[Reikala]] gli raccontiamo come siamo venuti in possesso e di quello che sappiamo fino ad ora poi glielo mostra, appena lo vede chiede se ha a che fare con la nave dragonidi al porto, noi neghiamo visto che l'abbiamo trovato nel territorio degli orchi, poi lo inizia a studiare un po', prima lo prova ad aprire senza riuscirci poi lo posa sul tavolo e prende un picchetto con una punta di diamante e un martello e con forza prova a rompere la pietra al centro cosa che non si scheggia, afferma di non sapere di cosa si tratta ma che il suo [[Thorian|Maestro]] possa sapere di cosa si tratta cosi propone di farlo vedere anche a lui, noi ci pensiamo un po' e alla fine decidiamo di accettare.

## Fine Sessione

Siamo nel laboratorio di [[Reikala]].

## Elenco

#### Personaggi
- [[Borin]]: Preside dell'[[Accademia Astronomica]] di [[Aresil]].
- [[Varnhald Trasmir]]: Famoso Mimicurgo di [[Belaver]].

#### Luoghi
- .

#### Oggetti
- **Agloss**: Il piu grande risultato di [[Varnhald Trasmir]].
