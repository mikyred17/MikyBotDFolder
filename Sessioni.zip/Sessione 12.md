## Eventi

#### Dopo il combattimento contro gli Orog

Appena finiamo di combattere Roland corre dentro al tempio Jin lo segue per dargli sostegno, poi va verso il suo compagno, intanto io e thalrik sistemiamo l'Orog rimasto e lo leghiamo, poi controlliamo gli oggetti degli orchi e delle casse nel tempio.

Dopo aver raccolto tutti gli oggetti e consegnato a roland gli averi del tipo decidiamo di fermarci un attimo prima di proseguire nelle cripte del tempio, nella pausa Thalrik identifica gli oggetti trovati, una cinturare e un oggetto magico che apparteneva al suo compagno, poi vuole andare via da solo ma Jin lo convince che e pericoloso e quindi rimane.

### Cripte tempio

Una volta dentro notiamo che ci sono delle torce accese quindi cerchiamo di muoverci silenziosamente, poi sento un rumore provenire da una zona, ci dirigiamo di li quando un mostro ci appare conmbattiamo e lo sconfiggiamo ma ancora la battaglia non e finita una maga ci attacca ma dopo poco riusciamo a vincere catturandola.


## Fine Sessione
Ci lasciamo che abbiamo appena catturato la maga

## Elenco

#### Personaggi
- . 

#### Luoghi
- .

#### Oggetti
- .


