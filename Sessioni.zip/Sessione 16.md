
## Eventi

### Piani per il Rientro

La mattina discutiamo del manufatto, poi ci confrontiamo su come rientrare dal confine con l’oggetto in nostro possesso. Decidiamo di non attraversare il blocco principale e iniziamo a cercare una via alternativa. Alla fine, scegliamo di dirigerci verso le colline dei giganti.

### Effetti del Manufatto

Nel frattempo, [[Thalrik]] identifica un paio di oggetti, e poi prova a identificare il Grimvox solo che non riesce completamente e nota che la magia svanisce nel mentre poi [[Zubel]] prova a trasformarsi con il grimvox addosso dopo poco tempo la trasformazione svanisce senza averla interrotta, siamo certi che il manufatto causa anomalie nella magia, rendendola instabile.

### Confidenze sul Passato

Una volta stabilito il piano, ci mettiamo in viaggio. Durante il cammino, io e [[Thalrik]] parliamo un po’ della mia famiglia, della legione e del mio passato, con il tempo sto raccontando sempre di piu di me, un gruppo molto eterogeneo ma particolare, attualmente sono molto vicino con thalrik.

### Incontri Notturni

La sera ci accampiamo. Durante la notte, solo [[Thalrik]] e [[Jin]] si trovano faccia a faccia con uno strano scheletro. L’incontro resta circoscritto a loro due…
[[Jin]] usando il suo potere divino non scorge nessun presenza particolare (Non Morto, Demoni, Fey).

## Fine Sessione

la notte non è ancora terminata. [[Jin]] e [[Thalrik]] sono ancora con lo scheletro.

## Elenco

#### Personaggi
- [[Skeldy]]: Scheletro apparso in sogno a [[thalrik]] e [[jin]].

#### Luoghi
- Colline dei Giganti: Strada che abbiamo scelto per tornare a [[Eldoria]].

#### Oggetti
- Inventario di [[Skeldy]].
