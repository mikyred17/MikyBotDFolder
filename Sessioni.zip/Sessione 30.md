
## Eventi

### Locanda

I mostri che infestano pyraxis sono delle mostruosità,

- perché le creature vengono trasformate dai cristalli: e come se quell'evento abbia mutato l'ambiente e che abbia modificato nell'appunto le creature e l'ambiente stesso.

- ce un differenza tra frammenti di cuori di kaelzor e cristalli di drago.
	1. **Frammenti del cuori di Kaelzor**: sono i cristalli che cerca lui e che sono quelli nel Grimvox 
	2. **Frammenti del corpo di Kaelzor**: che sono quelli sparsi a draconia e nei mari vicini.

## Fine Sessione


## Elenco

#### Personaggi
- .

#### Luoghi
- .

#### Oggetti
- .
