## Eventi

### Riunione e Avamposto

Dopo essermi riunito con Thalrik e mi racconta un po quello che e successo con i Three-Kri, ci avviciniamo agli altri, dopo aver deciso di proseguire e attaccare di giorno.
Dopo poche ore raggiungiamo questa zone molto arida trovando solo case coperte di polvere e distrutte, io e Roland decidiamo di avanzare per capire come era la situazione creando una connessione telepatica con gli altri.

Una volta vicino agli edifici, notiamo che sono presenti stendardi con il simbolo di un albero e altri con un occhio, le strutture sono disabitate e si notano anche una serie di teschi, poi avvisiamo il via libera agli altri e si avvicinano a noi, in una casa Roland riconosce il cavallo del compagno morto di mancanza di cibo o acqua.

### Tempio

Poi sempre noi 2 decidiamo di avanzare fino al tempio indicato notiamo del movimento, muovendoci nel perimetro notiamo 4 orog (2 che dormono) e un ettin, riferiamo agli altri il nostro piano di voler uccidere un'orog mentre dorme, mentre ci aviamo *Roland vede il suo compagno morto per terra* al centro del tempio facendoci individuare da un orog che era sveglio, riusciamo a riprendere la situazione e colpiamo prima che possono muoversi uccidendo uno, poi la situazione peggiora avverto gli altri e cerchiamo di scappare ci riuniamo agli altri con un po di difficolta ma riusciamo a ribaltare la situazione sconfiggendoli e catturandone uno.

## Fine Sessione
Appena finito il combattimento contro gli Orog

## Persone Luoghi e Oggetti della sessione

#### Personaggi
- .

#### Luoghi
- **Tempio dell'avamposto**: un tempio di un avamposto umano abbandonato.

#### Oggetti
- .
