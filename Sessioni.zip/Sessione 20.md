
## Eventi

### Discussioni lettera

Mentre viaggiamo discutiamo della lettera io faccio notare che forse il diario di cui si parlava nella missiva puo essere il diario di [[Aurelion Duval]], dove forse stanno cercando il "Codex Linguae" un cifrario di lingue rare e antiche, per decifrare cio che ce scitto sopra.

### Gigante

Dopo svariate ora di viaggio [[zubel]] ferma il carro e indica per terra qualcosa, io scendo e controllo il punto indicato per capire che si tratta di una trappola, poi [[Thalrik]] prende la vista del suo gufo per controllare la zona e nota un movimento tra gli alberi, e un gigante inizia un combattimento andato piuttosto bene era solo e noi eravamo 5, ma lo scontro non e stato silenzioso e ha attirato un Roc.

### Il Roc

Non facciamo in tempo a rendercene conto che e gia in picchiata su di noi cerchiamo di nasconderci, [[zubel]] usa un incantesimo per creare una nube di oscurita, ci muoviamo dentro ma [[jin]] mi viene incontro facendomi uscire cosi il roc decide di puntare verso di me riuscendo ad afferarmi, cercando di portarmi via ma riesco a liberarmi poi lui inizia a provare a prenderci ma riusciamo a sconfiggerlo.

Ci sistemiamo e decidiamo di prendere delle parti dal roc che si suppongono costose.

Mentre ci sistemiamo sento [[Deymar]] sussurare
> *Vi devo di nuovo la vita... Sovrano Pallido*

## Fine Sessione

Dopo il combattimento contro il roc.

## Elenco

#### Personaggi
- .

#### Luoghi
- .

#### Oggetti
- .
