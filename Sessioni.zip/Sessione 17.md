
## Eventi

### Skeldy

Lo scheletro dopo un breve presentazione fa scendere dalle spalle un armadio che apre e notano un ammontare di oggetti dal piu vario utilizzo: elenco oggetti di skeldy.
Poi chiede se vogliono comprare qualcosa, lui fa che se siamo dei buoni clienti ci rincontreremo, poi dopo un po di contrattazioni decidono di:

*Vendere*:
- Le Palle Sacre + 200 mo

*Comprano*:
- NetherBags
- Lampada dei Desideri
- Missiva del Sacro Corvo
- Mappa dei Piri Reis

poi [[thalrik]] usa una magia e crea un armatura simulando le scaglie di drago sul libro, e chiede se sono vere, skeldy risponde che non erano un armatura, e aggiunge si sono vere poi in un lampo e mattina loro si svegliano e in un vedo che queste cose sono di fianco a loro, io ero di guardia con zubel non abbiamo visto nulla.

dopo una breve discussione su di lui decidiamo di proseguire per le colline.


## Fine Sessione

## Elenco

#### Personaggi
- .

#### Luoghi
- **Colline dei Giganti**

#### Oggetti
- .
